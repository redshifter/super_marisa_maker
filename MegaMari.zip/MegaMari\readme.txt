MegaMari by Red Shifter

A level based on a certain level in MegaMari, the hit 2006 game from Twilight Frontier. They might as well be the official source of Touhou games at this point.

There's a few things out of place (on purpose) and the number of enemies is a lot lower (for playability), but I otherwise copied the original very closely.

It's a nice setpiece, but I think I'll stick with making completely original levels...


VERSION HISTORY

Version 1.0 (2022-04-14)
- Released map