KusoWall by Red Shifter

welcome to whatever the fuck this is

mario is way different than marisa and this idea was way dumber than i thought it would be. therefore it is kuso

i've always had a hard rule not to release my first map ever made for any game, but i'm drunk so screw the rules

i'll try harder next time

i don't know if it's possible to get all stars (and by extension the Extra exit) but Normal exit should be plausible


VERSION HISTORY

version 1.0 (2022-04-13)
- why the fuck would i ever release another version of this shit