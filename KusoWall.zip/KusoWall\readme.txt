KusoWall by Red Shifter

welcome to whatever the fuck this is

mario is way different than marisa and this idea was way dumber than i thought it would be. therefore it is kuso

i've always had a hard rule not to release my first map ever made for any game, but i'm drunk so screw the rules

i'll try harder next time


VERSION HISTORY

version 1.0.1 (2022-04-14)
- removed the comment about not knowing if all stars can be acquired because claude did it
- the actual map was not changed

version 1.0 (2022-04-13)
- why the fuck would i ever release another version of this shit