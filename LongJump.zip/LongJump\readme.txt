LongJump by Red Shifter

Just how far can Marisa jump, anyway...

Use the ice jump bug to get absurd height, while going as far as you can. Or turn it into a flying/hover challenge. It's really up to you.

Your score for a jump is the FIRST STAR YOU PICK UP. Every 20 is numbered. Each long line is 10, while each short line is 5. Just drill kick and note where the star was (or watch an instant replay).

My best score with hovering is 256. Can you go 1000 tiles?

(Because if you can, I'll have to make this bigger...)

VERSION HISTORY

Version 1.0 (2023-03-20)
- Released map. Length: 1000