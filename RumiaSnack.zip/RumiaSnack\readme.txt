RumiaSnack by Red Shifter

Puzzles abound, and when it's all said and done, it's time to feed Rumia a snack...

This is one of those levels where I made a bunch of space and then filled it all up with stuff. I made a few levels like this for NSMBW but most of them are trapped in the void...


VERSION HISTORY

Version 1.0 (2022-04-16)
- Released map