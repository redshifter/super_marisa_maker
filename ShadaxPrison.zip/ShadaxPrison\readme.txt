just a lavel with a pipe that goes back and forth between two areas

not like a cool secret stage or anything

it's not even the correct pipe object

and it doesn't even look right
